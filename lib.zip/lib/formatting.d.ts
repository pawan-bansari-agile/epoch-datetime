export declare function formatEpoch(epoch: number, format?: string, tz?: string): string;
