export declare function convertTimezone(epoch: number, toTz: string): number;
export declare function startOfDay(epoch: number, tz?: string): number;
export declare function endOfDay(epoch: number, tz?: string): number;
